import csv
import re

keyword = '=====================Executing query: ===================='
keywordLength = len(keyword)

# regex = re.compile(".*data_([A-Z]{2}).*")
# queries = set()

query2count = {}


with open('source/sql UAT 2023-11-22 - 2023-11-27.csv', newline='') as file:
    reader = csv.DictReader(file)
    for row in reader:
        last = row['\ufeffLogEntry']
        index = last.find(keyword)
        target = last[index + keywordLength:]

        target = target.replace('""', '"').replace('"', '\'')

        # replace type_='xxx' condition to special mark
        typeCondition = None
        typeConditionMatch = re.search(r'type_[^\']*\'[^\']*\'', target)

        if typeConditionMatch:
            typeCondition = typeConditionMatch.group()
            target = target.replace(typeCondition, 'typeCondition')

        # replace "in ['xxx','xxx']"" criteria
        target = re.sub(r'(?i)in\s+\[[^\[]*\]',
                        ' IN [\'strValue\'] ', target)

        # replace value for any field value started with '%' after 'like' keyword
        target = re.sub(
            r'\'\%[^\']+\'', '\'%strValue\'', target)

        # replace value for any field value not started with '%',
        # 括号()代表分组, 这里有三对括号代表通过正则匹配后的内容包含3个分组,
        # 第二个参数继续引用正则将2号分组和3号分组之间的内容替换成strValue
        target = re.sub(r'([^strValue])(\')[^\%^\']+(\')',
                        r'\1\2strValue\3', target)
        target = re.sub(r'(=)\s*[^\%^\'^\s]+[\s+]([^\'])',
                        r'\1 notStrValue \2', target)

        # replace back the "type_='xxx'" condition
        if typeCondition is not None:
            target = target.replace('typeCondition', typeCondition)

        # remove offset and limit
        target = re.sub(r'\s+(?i)offset.*', '', target)
        target = re.sub(r'\s+(?i)limit.*', '', target)

        target = ' ' + target + ' '

        target = re.sub(r'([^>^<])\s*=\s*', r'\1 = ', target)
        target = re.sub(r'\s*>=\s*', ' >= ', target)
        target = re.sub(r'\s*<=\s*', ' <= ', target)
        target = re.sub(r'\s*<>\s*', ' <> ', target)

        # to upper case the key words
        target = re.sub(r'\s+(?i)and\s+', ' AND ', target)
        target = re.sub(r'\s+(?i)where\s+', ' WHERE ', target)
        target = re.sub(r'\s+(?i)from\s+', ' FROM ', target)
        target = re.sub(r'(?i)select\s+', 'SELECT ', target)
        target = re.sub(r'\s+(?i)delete\s+', 'DELETE ', target)
        target = re.sub(r'\s+(?i)update\s+', 'UPDATE ', target)
        target = re.sub(r'\s+(?i)order\s+(?i)by\s+', ' ORDER BY ', target)
        target = re.sub(r'\s+(?i)desc\s+', ' DESC ', target)
        target = re.sub(r'\s+(?i)asc\s+', ' ASC ', target)

        target = re.sub(r'\s+(?i)sum\(', ' SUM(', target)
        target = re.sub(r'\s+(?i)count\(', ' COUNT(', target)
        target = re.sub(r'\s+(?i)in\s+', ' IN ', target)
        target = re.sub(r'\s+(?i)as\s+', ' AS ', target)
        target = re.sub(r'\s+(?i)is\s+', ' IS ', target)
        target = re.sub(r'\s+(?i)like\s+', ' LIKE ', target)
        target = re.sub(r'\s+(?i)missing\s+', ' MISSING ', target)
        target = re.sub(r'\s+(?i)null\s+', ' NULL ', target)
        target = re.sub(r'\s+(?i)not\s+', ' NOT ', target)
        target = re.sub(r'\s+(?i)any\s+', ' ANY ', target)
        target = re.sub(r'\s+(?i)end\s+', ' END ', target)
        target = re.sub(r'\s+(?i)satisfies\s+', ' SATISFIES ', target)

        # remove any space at start and end
        target = re.sub(r'\s+$', '', target)
        target = re.sub(r'^\s+', '', target)

        # replace bucket
        target = re.sub(r'`?dpas_data_(\S+)`?\s+', 'dpas_data_VN ', target)

        # extract 'type_' value
        typeValue = 'None'
        if typeCondition is not None:
            typeValueMatch = re.search(r'\'[^\']*\'', typeCondition)
            if typeValueMatch:
                typeValue = typeValueMatch.group().lstrip('\'').rstrip('\'')

        target = typeValue + '+++' + target

        if target in query2count:
            count = query2count[target]
            count += 1
            query2count[target] = count
        else:
            query2count[target] = 1

        # queries.add(target)

print(len(query2count))

with open('target/sql UAT 2023-11-22 - 2023-11-27 distinct queries.csv', 'w', newline='') as file:
    fieldnames = ['ModelType', 'Count', 'Query']
    writer = csv.DictWriter(file, fieldnames)
    writer.writeheader()

    sortedKeys = sorted(query2count)

    for query in sortedKeys:

        # region = None
        # regionMatch = regex.match(target)
        # if regionMatch is not None:
        #     region = regionMatch.group(1)
        # else:
        #     region = 'None'

        index = query.find('+++')
        count = query2count[query]
        writer.writerow(
            {'ModelType': query[0:index], 'Count': count, 'Query': query[index+3:]})
